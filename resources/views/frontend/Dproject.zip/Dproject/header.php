<!DOCTYPE html>
<html lang="zxx">
<head>
        <!-- Required meta tags -->

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Link of CSS files -->

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/remixicon.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/odometer.min.css">
        <link rel="stylesheet" href="assets/css/fancybox.css">
        <link rel="stylesheet" href="assets/css/aos.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        <link rel="stylesheet" href="assets/css/dark-theme.css">
        <title>Teli - Digital Healthcare & Medical Services HTML Template</title>
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>
    <body>

        <!--Preloader starts-->

        <div class="loader js-preloader">
            <div class="absCenter">
                <div class="loaderPill">
                    <div class="loaderPill-anim">
                        <div class="loaderPill-anim-bounce">
                            <div class="loaderPill-anim-flop">
                                <div class="loaderPill-pill"></div>
                            </div>
                        </div>
                    </div>
                    <div class="loaderPill-floor">
                        <div class="loaderPill-floor-shadow"></div>
                    </div>
                </div>
            </div>
        </div>

        <!--Preloader ends-->

        <!-- Theme Switcher Start -->
        <!-- <div class="switch-theme-mode">
            <label id="switch" class="switch">
                    <input type="checkbox" onchange="toggleTheme()" id="slider">
                    <span class="slider round"></span>
            </label>
        </div> -->

        <!-- Theme Switcher End -->

        <!-- Page Wrapper End -->
        <div class="page-wrapper">

            <!-- Header Section Start -->
            
            <header class="header-wrap style1">
                <div class="header-top">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <div class="header-top-left">
                                    <ul class="contact-info list-style">
                                        <li>
                                            <span><i class="flaticon-email-1"></i></span>
                                            <p> <a href="mailto:support@noormedicare.com" 
                                            target="" rel="">support@noormedicare.com</a></p>
                                        </li>
                                        <li>
                                            <span><i class="ri-phone-fill"></i></span>
                                            <a href="tel:9555197411"> +91-9555197411</a>
                                        </li>
                                        <li>
                                            <span><i class="ri-map-pin-fill"></i></span>
                                            <p> New Delhi - 110044, India</p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="header-top-right">
                                    <ul class="social-profile list-style style1">
                                        <li>
                                            <a href="https://facebook.com/">
                                                <i class="ri-facebook-fill"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://twitter.com/">
                                                <i class="ri-twitter-fill"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://linkedin.com/">
                                                <i class="ri-linkedin-fill"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://pinterest.com/">
                                                <i class="ri-pinterest-line"></i>
                                                
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-bottom">
                    <div class="container">
                        <nav class="navbar navbar-expand-md navbar-light">
                           <a class="navbar-brand" href="index.php">
                                <img class="logo-light" src="assets/img/2logo.png" style=" width: 100%; height: 50px; " alt="logo">
                                <img class="logo-dark" src="assets/img/logo-white.png" alt="logo">
                            </a>
                            <div class="collapse navbar-collapse main-menu-wrap" id="navbarSupportedContent">
                                <div class="menu-close d-lg-none">
                                    <a href="javascript:void(0)"> <i class="ri-close-line"></i></a>
                                </div>
                                <ul class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a href="index.php" class="nav-link active">
                                            HOME
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.php" class="nav-link">
                                            ABOUT
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link">
                                        SPECIALITIES 
                                            <i class="ri-arrow-down-s-line"></i>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="specialities-details.php" class="nav-link">Cardiology</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="orthopaedic.php" class="nav-link">Orthopaedic</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="neurology.php" class="nav-link">Neurology & brain surgery</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="urology.php" class="nav-link">Urology</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="haematology.php" class="nav-link">Haematology</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="oncology.php" class="nav-link">Oncology</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="ent.php" class="nav-link">ENT</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="pulmonology.php" class="nav-link">Pulmonology</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="specialities.php" class="nav-link">See All Specialities </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link">
                                            HOSPITALS 
                                            <i class="ri-arrow-down-s-line"></i>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="hospitalsdel.php" class="nav-link">Medanta</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="fortisfmri.php" class="nav-link">Fortis FMRI</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="artemis-hospital.php" class="nav-link">Artemis Hospital</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="specialtyhospital.php" class="nav-link">Max Super Specialty Hospital</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="apollohospital.php" class="nav-link">Indraprastha Apollo Hospital</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="blkhospital.php" class="nav-link">
                                                    BLK Hospital  
                                                </a></li>
                                                    <li class="nav-item">
                                                        <a href="manipalhospital.php" class="nav-link">Manipal Hospital</a>
                                                    </li>
                                                     <li class="nav-item">
                                                        <a href="metrohospitals.php" class="nav-link">Metro Hospitals</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="hospitals.php" class="nav-link">See All Hospitals</a>
                                                    </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link">
                                        OUR SPECIALISTS 
                                            <i class="ri-arrow-down-s-line"></i>
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="doctordels.php" class="nav-link">
                                                Naresh Trehan, Cardiology 
                                                </a>
                                                </li>
                                                
                                                    <li class="nav-item">
                                                        <a href="arunprasad.php" class="nav-link">Dr. Arun Prasad, Â G I Surgeon</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="kumudhanda.php" class="nav-link">Dr. Kumud Handa, Â ENT Surgeon</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="anilarora.php" class="nav-link">Prof Dr. Anil Arora,Orthopaedics </a>
                                                    </li>
                        
                                            <li class="nav-item">
                                                <a href="narmadaprasad.php" class="nav-link">
                                                Dr. Narmada Prasad Gupta, Urology
                                                    
                                                </a>  </li>
                                                
                                                    <li class="nav-item">
                                                        <a href="" class="nav-link">
                                                        Dr. Prof K.S Gopinath, Oncologist
                                                        </a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="vikasdua.php" class="nav-link">Vikas Dua, Oncologist</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="" 
                                                        class="nav-link">Dr. V. S. Mehta, Neuro Surgeons</a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a href="doctors.php" 
                                                        class="nav-link">See All Specialists</a>
                                                    </li>
                                        </ul>
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a href="contact.php" class="nav-link">GALLERY</a>
                                    </li> -->
                                    <li class="nav-item">
                                        <a href="gallery.php" class="nav-link">GALLERY</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="contact.php" class="nav-link">CONTACT US</a>
                                    </li>
                                  
                                    <li class="nav-item d-lg-none">
                                        <a href="appointment.php" 
                                        class="nav-link btn style1">Book Appointment</a>
                                    </li>
                                </ul>
                                <div class="other-options md-none">
                                    <div class="option-item">
                                        <a href="appointment.php" class="btn style1">Book Appointment</a>
                                    </div>
                                </div>
                                
                            </div>
                        </nav>
                        <div class="search-area">
                            <input type="search" placeholder="Search Here..">
                            <button type="submit"><i class="ri-search-line"></i></button>
                        </div>
                        <div class="mobile-bar-wrap">
                            <button class="searchbtn d-lg-none"><i class="ri-search-line"></i></button>
                            <div class="mobile-menu d-lg-none">
                                <a href="javascript:void(0)"><i class="ri-menu-line"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>  
            <!-- Header Section End -->
