<?php include 'header.php'; ?>

            <!-- Content Wrapper Start -->
            <div class="content-wrapper">

                <!-- Breadcrumb Start -->
                <div class="breadcrumb-wrap bg-f br-1">
                    <div class="container">
                        <div class="breadcrumb-title">
                            <h2>Privacy Policy</h2>
                            <ul class="breadcrumb-menu list-style">
                                <li><a href="index.php">Home </a></li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Breadcrumb End -->

                <!-- Privacy Policy Section start -->
                <section class="terms-wrap pt-100 pb-75 mb-10">
                    <div class="container">
                        <div class="row gx-5">
                            <div class="col-lg-12">
                                <div class="single-terms">
                                    <h3>Protection of Personal Information</h3>
                                    <p>
                                    This Policy explains how “Noor Medicare”, as the data custodian, will handle any personal information you entrust to us when you visit our website or sign up to utilize the “Noor Medicare” platform.
                                    </p>

                                    <h3>What kind of private information do we gather?</h3>
                                    <p>
                                        Personal information and data relating to your use of this website & our
                                        platform may be collected, stored, and used by us ("Collected Information"). 
                                        Your IP address, geographic location, browser type, referral source, duration
                                         of visit, and number of page views are all personally identifiable information that we gather about your computer and your use of this platform.
                                    </p>
                                  <p>
                                  As part of our services, we will provide the hospital/doctor with relevant medical records to better understand your situation. No third parties unrelated to fulfilling your service requests or advertising platforms have access to your data.
                                  </p>

                                    <h3>Cookies and other technologies we use for tracking purposes</h3>

                                    <p>
                                    Cookies are used on this site. A cookie is a small text file a web server may send to a browser that the browser can then save for future reference. The text file is resent to the server whenever a page is requested from the server. So, the server can recognize the browser and keep tabs on its activity. Your web browser may save a "cookie" from our server on your hard drive. The collected information includes data gleaned through cookies. It's also possible that you'll get cookies from the sites we partner with for advertising and other services. If you want, you can disable the cookie acceptance in most browsers. However, disabling cookies will have a detrimental influence on the accessibility of many websites, including this one (with Internet Explorer, you may disable cookies by choosing "Tools," "Internet Options," "Privacy," and selecting "Block all cookies" using the sliding selection). Third-party service providers may be used to run this site and assist us monitor, collecting, and analyzing information about your interactions with this website and the data you submit, including via the use of such providers' cookies on your computer, to enhance our services and this site.
                                    </p>

                                    <h3>Justification for using gathered data</h3>

                                    <p>Personal information and other data collected 
                                        will be used for the following purposes:</p>

                                        <p>communicate with you via channels open to the general public (such as email, phone, 
and messaging).</p>

<p>control and enhance the functionality of this site and the platform;</p>

<p>Modify and change content such as text, photos, videos, 
and links to make the surfing experience more relevant to the user;</p>

<p>give you promotional materials and other information about our company and the companies of carefully chosen third parties that we believe may be 
of interest to you through regular mail, email, or other electronic means with your
 express permission.</p>

 <p>share aggregated user data with third-party businesses. We will never sell or share information that might be used to identify a specific user.</p>

 <p>enable us to monitor the success rate of inquiries sent via our system while limiting access to the actual answer content.</p>

<p>Inform other users by sharing personal accounts in written text, media files, and visuals. Users may submit material for review and removal if they have concerns.</p>
                                </div>
                                <!-- <div class="single-terms">
                                    <h3>How We Use Cookies</h3>
                                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nihil eveniet quas dignissimos doloribus ea pariatur corrupti rerum deserunt, ipsum, ipsa eos veniam aspernatur fuga, optio soluta? Libero neque reiciendis cupiditate dolores nam. Earum eius similique sapiente. Iure, sit non. At fuga ipsam veniam.</p>
                                    <ul class="content-feature-list style2 list-style ">
                                        <li><i class="ri-check-double-line"></i> Lorem ipsum dolor, sit amet.</li>
                                        <li><i class="ri-check-double-line"></i>Amet consectetur adipisicing elit.
                                            Officia, odit!</li>
                                        <li><i class="ri-check-double-line"></i>Aquaerat ipsa quis possimus.</li>
                                        <li><i class="ri-check-double-line"></i>Lorem, ipsum dolor sit amet
                                            consectetur adipi.</li>
                                        <li><i class="ri-check-double-line"></i>Consectetur adipisicing elit.
                                            Voluptatibus, dignissimos.</li>
                                        <li><i class="ri-check-double-line"></i>Highly professional administration.
                                        </li>
                                    </ul>
                                </div> -->
                                <div class="single-terms">
                                    <h3>Legitimate justifications</h3>
                                    <p>Our legitimate interest in gaining insight into how users engage with
                                         this webpage or the platform, and in developing more effective methods
                                          of promoting our products and services, provides the legal basis for 
                                          the processing of your Collected Information if you are a registered 
                                          platform user or a user of the website.</p>
                                </div>
                                <div class="single-terms">
                                    <h3>Data privacy and protection</h3>
                                    <p>
                                    Your personal information is important to us, and we will protect it against unauthorized access, disclosure, copying, use, or disposal. We cannot ensure the security of any information sent through the Internet due to the insecure nature of this medium. All information you provide us or that we learn about you will be kept safe on our servers. Your obligation to maintain the secrecy of your passwords is absolute. Simply put, we will not be requesting any passwords from you.
                                    </p>
                                </div>
                                <div class="single-terms">
                                    <h3>Sharing Acquired Data</h3>
                                    <p>Our office is situated in the city of Gurgaon on the Indian subcontinent. We get such information when you provide information about yourself via our website or the platform. Personal information sent to us will be processed following both Indian law and EU-US privacy regulations. Following the forward transfer principles of the IT rules and laws for data protection, we may disclose your data to other parties, as mentioned in Sharing Collected Information. Data center hosting, customer relationship management, corporate email services, software as a service (SaaS) survey solutions, and software as a service (SaaS) IT service management are all examples of the kind of third-party services that we use to help us provide our goods and services to you. These service providers have all been vetted to ensure they are trustworthy. They will only be given access to your personal information if required to carry out the services they have been contracted to offer. They are required to keep the information private. They are prohibited from utilizing it for any reason other than what was intended.</p>

                                </div>
                                <div class="single-terms">
                                    <h3>Third-Party sources</h3>
                                    <p>There are external connections available on the site. We have no control over the privacy practices of other websites or the operators of those websites, including their collection or use of any personal information you provide when visiting such other sites.</p>
                                </div>

                                <div class="single-terms">
                                    <h3>Personal information disclosure</h3>
                                    <p>Users may request access to their personal information stored by “Noor Medicare” and have any erroneous or incomplete data rectified, updated, or removed. To get in touch with us, check out the information on our Contact Us page. As a user of our platform, we rely on you to keep your data accurate and up-to-date to the degree required to fulfill the purposes for which it was acquired, such as your contact information, so that we may send you billing details.</p>
                                </div>

                                <div class="single-terms">
                                    <h3>Your Rights</h3>
                                    <p>Suppose any personal information is erroneous, outdated, or otherwise wrong. In that case, you have the right to update it (that is, rectified). The right to access one's personal information is guaranteed (including receiving a copy thereof). You have the right to revoke permission at any time, which will not impact the legality of the processing based on consent before its withdrawal if we ever treat your data based on consent. Your right to have deleted information on you exists, too, and it applies under certain conditions.</p>
                                    <p>Suppose you believe that the processing of your personal information violates the law. In that case, you have the right to file a complaint with the supervisory authority of your usual residence, employment, or the location where the alleged violation occurred.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Privacy Policy Section end -->

            </div>
            <!-- Content wrapper end -->

            <?php include 'footer.php';?>