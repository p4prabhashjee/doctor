<?php include ('header.php'); ?>

            <!-- Content Wrapper Start -->
            <div class="content-wrapper">

                <!-- Breadcrumb Start -->
                <div class="breadcrumb-wrap bg-f br-1">
                    <div class="container">
                        <div class="breadcrumb-title">
                            <h2>Specialities at NoorHealth</h2>
                            <ul class="breadcrumb-menu list-style">
                                <li><a href="index.php">Home </a></li>
                                <li>Specialities</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Breadcrumb End -->

           

                <!-- Service Section Start -->
                <section class="service-wrap ptb-100 bg-athens">
                <div class="container">
                    <div class="section-title style1 text-center mb-40">
                        <!-- <span>Our Services</span> -->
                        <h2>Speciality and Treatment or Condition</h2>
                    </div>
                    <div class="row">
                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/cardiology_1660300008.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Cardiology</a></h3>
                                <p>At NoorMediCare, It is considered efficient onus to offer proficient  layout.</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/orthopaedic_1660546035.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="specialities-details.php">Orthopaedic</a></h3>
                                <p>At NoorMediCare, its team of orthopedic doctors have an in-depth under.</p>
                                <a href="specialities-details.php" 
                                class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/neurology-and-brain-surgery_1660531139.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Neurology & brain surgery</a></h3>
                                <p>Neurology and Brain Surgery have always been the more sophisticated sp</p>
                                <a href="specialities-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/urology_1660531281.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Urology</a></h3>
                                <p>Not many people are aware of it, but urological problems are more comm.</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/haematology_1660531395.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Haematology</a></h3>
                                <p>At NoorMediCare, it offers a full spectrum for the diagnosis and treat</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/oncology_1660531537.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Oncology</a></h3>
                                <p>Cancer is a severe disease which not only adversely impacts the physic</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/pulmonology_1660531759.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Pulmonology</a></h3>
                                <p>At NoorMediCare, it offers diagnostic as well as treatment facilities.</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/ophthalmology_1661065360.jpg" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Ophthalmology</a></h3>
                                <p>The eye, although not vital, is yet one of the most significant parts.</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>

                        <div class=" col-xl-4 col-lg-4 col-md-4 col-sm-10 col-12 my-3 ">
                        <div class="service-card style1">
                            <div class="service-img">
                                <img src="assets/img/services/ent_1660531665.png" alt="Image">
        
                            </div>
                            <div class="service-info">
                                <h3><a href="service-details.php">Ent</a></h3>
                                <p>At NoorMediCare, It is considered efficient onus to offer proficient  layout.</p>
                                <a href="service-details.php" class="link style2">Read More</a>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Service Section End -->


            </div>
            <!-- Content wrapper end -->
            <?php include ('footer.php'); ?>