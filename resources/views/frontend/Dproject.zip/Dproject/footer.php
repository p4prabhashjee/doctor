     <!-- Footer Section Start -->
     <footer class="footer-wrap">
                <div class="container">
                    <div class="row pt-100 pb-75">
                      
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                            <div class="footer-widget">
                                <h3 class="footer-widget-title">Our Specialities</h3>
                                <ul class="footer-menu list-style">
                                    <li>
                                        <a href="index-2.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Cardiology
                                        </a>
                                    </li>
                                    <li>
                                        <a href="orthopaedic.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                           Orthopaedic
                                        </a>
                                    </li>
                                    <li>
                                        <a href="neurology.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                          Neurology & brain surgery                         
                                        </a>
                                    </li>
                                    <li>
                                        <a href="urology.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                           Urology
                                        </a>
                                    </li>
                                    <li>
                                        <a href="haematology.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                         Haematology
                                        </a>
                                    </li>
                                    <li>
                                        <a href="oncology.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Oncology
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ent.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                         ENT
                                        </a>
                                    </li>
                                    <li>
                                        <a href="pulmonology.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                         Pulmonology
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                            <div class="footer-widget">
                                <h3 class="footer-widget-title">Hospitals</h3>
                                <ul class="footer-menu list-style">
                                    <li>
                                        <a href="hospitalsdel.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Medanta
                                        </a>
                                    </li>
                                    <li>
                                        <a href="fortisfmri.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                        Fortis FMRI
                                        </a>
                                    </li>
                                    <li>
                                        <a href="artemis-hospital.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                           Artemis Hospital
                                        </a>
                                    </li>
                                    <li>
                                        <a href="specialtyhospital.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Max Super Specialty Hospital
                                        </a>
                                    </li>
                                    <li>
                                        <a href="apollohospital.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                           Indraprastha Apollo Hospital
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blkhospital.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            BLK Hospital
                                        </a>
                                    </li>
                                    <li>
                                        <a href="manipalhospital.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                         Manipal Hospital
                                        </a>
                                    </li>
                                    <li>
                                        <a href="metrohospitals.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                          Metro Hospitals
                                        </a>
                                    </li>
                             
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 pe-xl-4">
                            <div class="footer-widget">
                                <h3 class="footer-widget-title">Quick Link</h3>
                                <ul class="footer-menu list-style">
                                    <li>
                                        <a href="about.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            About Us
                                        </a>
                                    </li>
                                       <li>
                                        <a href="blog.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Blog
                                        </a>
                                    </li>
                                    <li>
                                        <a href="doctors.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                          Doctors
                                        </a>
                                    </li>
                                    <li>
                                        <a href="gallery.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                         Gallery
                                        </a>
                                    </li>
                                    <li>
                                        <a href="privacy-policy.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                           Privacy & Policy
                                        </a>
                                    </li>

                                    <li>
                                        <a href="terms-conditions.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Terms-Conditions
                                        </a>
                                    </li>

                                    <li>
                                        <a href="contact.php">
                                            <i class="ri-arrow-right-s-line"></i>
                                            Contact Us
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-widget">
                                <h3 class="footer-widget-title">Contact Us</h3>
                                <ul class="contact-info list-style">
                                    <li>
                                        <i class="flaticon-map"></i>
                                        <h6>Location</h6>
                                        <p>F-89, Vishwakarma colony, Pul Pehladpur,
                                         New Delhi - 110044, India</p>
                                    </li>
                                    <li>
                                        <i class="flaticon-email-1"></i>
                                        <h6>Email</h6>
                                        <a href="https://templates.hibotheme.com/cdn-cgi/l/email-protection#d8b0bdb4b4b798acbdb4b1f6bbb7b5">
                                            <span class="__cf_email__" data-cfemail="f79f929b9b98b783929b9ed994989a">
                                            support@noormedicare.com</span></a>
                                    </li>
                                    <li>
                                        <i class="flaticon-phone-call-1"></i>
                                        <h6>Phone</h6>
                                        <a href="tel:9555197411"> +91 9555197411</a>
                                    </li>
                                </ul>
                                <ul class="social-profile pt-4 style1 list-style">
                                    <li>
                                        <a href="https://facebook.com/">
                                            <i class="ri-facebook-fill"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/">
                                            <i class="ri-twitter-fill"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://instagram.com/">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://linkedin.com/">
                                            <i class="ri-linkedin-fill"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="copyright-text"><i class="ri-copyright-line"></i> 
                <span>NoorMediCare</span>. Copyright ©2023 All rights reserved 
              </p>
            </footer>
            <!-- Footer Section End -->
    
        </div>
        <!-- Page Wrapper End -->
        
        <!-- Back-to-top button Start -->

         <a href="javascript:void(0)" class="back-to-top bounce">
            <i class="ri-arrow-up-s-line"></i></a>
            
        <!-- Back-to-top button End -->

        <!-- Link of JS files -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/aos.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/fancybox.js"></script>
        <script src="assets/js/jquery.appear.js"></script>
        <script src="assets/js/tweenmax.min.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>