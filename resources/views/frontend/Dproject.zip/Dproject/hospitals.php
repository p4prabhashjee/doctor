<?php include('header.php');?>
<div class="content-wrapper">

   <!-- Breadcrumb Start -->
   <div class="breadcrumb-wrap bg-f br-1 style1  portfolio-wrap ptb-100">
                    <div class="container">
                        <div class="breadcrumb-title">
                            <h2>Hospitals at NoorHealth</h2>
                            <ul class="breadcrumb-menu list-style">
                                <li><a href="index.php">Home </a></li>
                                <li>Hospitals</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Breadcrumb End -->


            <section class="  style1 portfolio-wrap ptb-100">
                <div class="container">
                    <div class="section-title style1 text-center mb-40">
                        <!-- <span>Our Portfolio</span> -->
                        <h2>Our Hospitals</h2>
                    </div>
                     <div class="row">
                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/medanta_1660564512.png" alt="Image">
                            </div>
                            <div class="service-info textsize p-2 text-center">
                                <h3><a href="hospitalsdel.php">Medanta</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>
                        
                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/fortis-fmri_1660564671.png" alt="Image">
                            </div>
                            <div class="service-info p-2 textsize text-center">
                                <h3><a href="service-details.php">Fortis FMRI</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>

                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/artemis-hospital_1660564920.png" alt="Image">
                            </div>
                            <div class="service-info p-2 textsize text-center">
                                <h3><a href="service-details.php">Artemis Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>

                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/max-super-specialty-hospital_1660565057.png" alt="Image">
                            </div>
                            <div class="service-info textsize p-2 text-center">
                                <h3><a href="service-details.php">Max-Super-Specialty-Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>

                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/indraprastha-apollo-hospital_1660565597.png" class="img-fluid"  alt="Image">
                            </div>
                            <div class="service-info p-2 textsize text-center">
                                <h3><a href="service-details.php">Indraprastha-Apollo-Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>

                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/blk-hospital_1660565762.png" alt="Image">
                            </div>
                            <div class="service-info  textsize p-2 text-center">
                                <h3><a href="service-details.php">Blk Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>

                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/metro-hospitals_1660566855 (1).png" alt="Image">
                            </div>
                            <div class="service-info  textsize p-2 text-center">
                                <h3><a href="service-details.php">Metro-Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>
                       
                       <div class="col-xl-3 col-md-3 col-lg-3 col-sm-12 col-12 my-3">
                       <div class="service-card style1">
                            <div class="service-img imgeffects">
                            <img src="assets/img/portfolio/manipal-hospital_1660566520.png" alt="Image">
                            </div>
                            <div class="service-info  textsize p-2 text-center">
                                <h3><a href="service-details.php">Manipal-Hospital</a></h3>
                                <span>Delhi & NCR</span>
                            </div>
                        </div>
                       </div>
                       <!-- <div class="text-center mt-10">
                        <div class="hero-btn ">
                                <a href="service-one.php" class="btn style1">View More</a>
                                </div>
                    </div> -->
                     </div>
                </div>
            </section>

<?php include('footer.php');?>