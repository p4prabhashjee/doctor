<?php 
include 'header.php';
?>

            <!-- Content Wrapper Start -->
            <div class="content-wrapper">

                <!-- Breadcrumb Start -->
                <div class="breadcrumb-wrap bg-f br-2">
                    <div class="container">
                        <div class="breadcrumb-title">
                            <h2>About Us</h2>
                            <ul class="breadcrumb-menu list-style">
                                <li><a href="index.php">Home</a></li>
                                <li>About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Breadcrumb End -->

                <!-- About Section Start -->
                <section class="about-wrap style1 ptb-100">
                    <div class="container">
                        <div class="row gx-5 align-items-center">
                            <!-- <div class="col-lg-6">
                                <div class="about-img-wrap">
                                    <img src="assets/img/about-bg.png"
                                     alt="Image" class="about-img-one">
                                 
                                </div>
                            </div> -->
                            <div class="col-lg-12">
                                <div class="about-content">
                                    <div class="content-title style1">
                                        <span>About Our Program</span>
                                        <h2>Take Care Of Your Health With Our 
                                            Health Package</h2>
                                        <p  class="text-justify">India has always been known for its sound medical discoveries. Over the decades there has been remarkable growth in providing quality medical services. Seeing this NoorMediCare is established under the vision of Mr. Jawed Akhtar,
                                             the founder of NoorMediCare and augmented a strong team of experts, well
                                              versed doctors, language translators, professionals from the medical tourism
                                               industry to render affordable and world-class services to overseas tourists.</p>
                                         <p  class="text-justify">Collective experiences of over 12 years, and knowledge of professionals, NoorMediCare has today become a trusted name in the medical tourism industry. The head office is located in New Delhi offering services covering PAN India.</p>
                                         <p>
                                         NoorMediCare is tied up with renowned multi-specialty hospitals, Ayurveda centers, medical clinics, yoga centers, travel companies, and visa agencies that help us in making you comfortable journey in India. Its team comprises of professionals who will be appointed to you from the time you decide to visit India. This dedicated expert will walk with you throughout your journey to India. Right from assisting you with medical procedures, your accommodation, travel etc.
                                         </p>
                                         <p  class="text-justify" >
                                            
NoorMediCare’s motto has been strong with fair determination ever since we started. Its eager is to take care of and be with you like shadow while you go through your medical treatment from welcome (arrival) to see off (departure) in our country. Even after you staying at your home NoorMediCare will must keep in touch with you and you may freely contact with us round the clock.
                                         </p>
                                    </div>

                                    <div class="row align-items-center">
                                        <div class="col-md-12">
                                            <ul class="content-feature-list list-style">
                                                <li><i class="ri-checkbox-circle-line"></i>
                                                Affordable & Transparent Medical Tourism Packages
                                                </li>
                                                <p>
                                                There is something different for everyone who decides to go with this. Keeping in mind the expenses you may have for your medical treatment is surprisingly comparable with others. NoorMediCare organization never wants to overload you with un-affordable packages. Since India is known for high-quality affordable medical services and will be maintained to keep it that way.
                                                </p>
                                                <li><i class="ri-checkbox-circle-line"></i>
                                                Stress-Free Reservations
                                                </li>
                                                <p>
                                                The only thing one’s need to do is just decide to come and will be taken care of the rest. NoorMediCare third-party travel vendors will make reservations stress free and our hospitality partners will take care of accommodation and meals.
                                                </p>
                                                <li><i class="ri-checkbox-circle-line"></i>
                                                Easy Visa Process & Insurance Service
                                                </li>
                                                <p>
                                                Visa procedures can be sometimes time taking. Most of the time you may have to constantly follow up with the vendors. No one needs to bother all the hard work that is needed NoorMediCare itself will manage. NoorMediCare is tied-up with multiple insurance companies. Its experts would guide and help you to buy the best policy as per suitability.  
                                                </p>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- About Section End -->


               
            
            </div>
            <!-- Content wrapper end -->

 <?php 
include 'footer.php';
?>